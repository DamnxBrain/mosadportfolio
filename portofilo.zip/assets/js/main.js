/* Renders the page from window.SITE (assets/js/content.js). No editing needed here. */
(function () {
  "use strict";
  var S = window.SITE;
  var lang = S.defaultLang;
  var filter = "all";
  var expIndex = 0;
  var $ = function (sel, root) { return (root || document).querySelector(sel); };

  try {
    var saved = localStorage.getItem("mm-lang");
    if (saved === "ar" || saved === "en") lang = saved;
  } catch (e) {}
  if (location.hash === "#en") lang = "en";
  if (location.hash === "#ar") lang = "ar";

  function esc(s) {
    return String(s == null ? "" : s).replace(/[&<>"']/g, function (c) {
      return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c];
    });
  }
  function pick(o, k) { return lang === "ar" ? o[k + "Ar"] || o[k] : o[k + "En"] || o[k]; }

  var ICONS = {
    meta: '<path d="M4 12a8 8 0 1 0 16 0 8 8 0 1 0-16 0"/><path d="M8 12a4 4 0 1 0 8 0 4 4 0 1 0-8 0"/><path d="M12 12h.01"/>',
    snap: '<path d="M5 18h14"/><path d="M7 18V9a5 5 0 0 1 10 0v9"/><path d="M10 11h.01M14 11h.01"/>',
    tiktok: '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="m10 9 5 3-5 3z"/>',
    wa: '<path d="M4 20l1.4-4A8 8 0 1 1 8 18.6z"/><path d="M9 10h6M9 13h4"/>',
    audit: '<circle cx="11" cy="11" r="6"/><path d="m20 20-4.3-4.3"/><path d="M9 11h4"/>',
    pen: '<path d="M4 20h4L19 9l-4-4L4 16z"/><path d="m13.5 6.5 4 4"/>',
  };
  function icon(name, size) {
    return '<svg width="' + (size || 26) + '" height="' + (size || 26) + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + ICONS[name] + "</svg>";
  }
  var ARROW = '<svg class="arrow" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M5 12h14M13 6l6 6-6 6"/></svg>';

  function waLink(T, number) {
    return "https://wa.me/" + number + "?text=" + encodeURIComponent(T.contact.waMessage);
  }
  var WA_ICON = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 20l1.4-4A8 8 0 1 1 8 18.6z"/><path d="M9.5 9.5c0 2.5 2.5 5 5 5l1-1.5-2-1-1 .8a4 4 0 0 1-2.3-2.3l.8-1-1-2z"/></svg>';

  function metricHTML(m) {
    var unit = lang === "ar" ? m.unitAr : m.unitEn;
    return '<div><span class="num">' + esc(m.value) + (unit ? "<small>" + esc(unit) + "</small>" : "") + "</span><span>" + esc(m[lang]) + "</span></div>";
  }

  function render() {
    var T = S.t[lang];
    var C = S.contact;
    var root = document.documentElement;
    root.lang = lang;
    root.dir = lang === "ar" ? "rtl" : "ltr";
    document.title = T.name + " — " + T.role;

    $("#skip").textContent = T.skipLink;
    $("#brand-name").textContent = T.name;
    var navKeys = ["clients", "about", "work", "services", "experience", "contact"];
    $("#nav").innerHTML = navKeys.map(function (k) { return '<a href="#' + k + '">' + esc(T.nav[k]) + "</a>"; }).join("");
    $("#lang-btn").textContent = T.langSwitch;
    $("#lang-btn").setAttribute("lang", lang === "ar" ? "en" : "ar");

    /* Hero */
    $("#hero").innerHTML =
      '<div class="wrap"><div class="hero-grid">' +
        '<div class="reveal">' +
          '<p class="kicker">' + esc(T.hero.kicker) + "</p>" +
          "<h1>" + esc(T.hero.title) + "</h1>" +
          '<p class="lead">' + esc(T.hero.lead) + "</p>" +
          '<div class="cta-row">' +
            '<a class="btn btn-primary" href="#work">' + esc(T.hero.ctaWork) + ARROW + "</a>" +
            '<a class="btn btn-ghost" href="#contact">' + esc(T.hero.ctaContact) + "</a>" +
            (C.cvUrl ? '<a class="btn btn-link" href="' + esc(C.cvUrl) + '" target="_blank" rel="noopener">' + esc(T.hero.ctaCv) + "</a>" : "") +
          "</div>" +
        "</div>" +
        '<figure class="portrait reveal d2" style="margin:0">' +
          '<img src="' + esc(S.photo) + '" width="720" height="720" alt="' + esc(T.name) + '" fetchpriority="high">' +
          (S.heroTicker && S.heroTicker.length ? (function (k) {
            return '<figcaption class="ledger-chip"><span class="chip-label"><i class="live"></i><span class="t-label">' + esc(k[lang]) + '</span></span><span class="t-value-wrap"><span class="num t-value">' + esc(k.value) + "<small>" + esc(lang === "ar" ? k.unitAr : k.unitEn) + "</small></span></span></figcaption>";
          })(S.heroTicker[0]) : "") +
        "</figure>" +
      "</div>" +
      '<div class="facts reveal d3">' +
        T.facts.map(function (f) {
          return '<div class="fact"><span class="num">' + esc(f.value) + "<small>" + esc(f.unit) + "</small></span><span>" + esc(f.label) + "</span></div>";
        }).join("") +
      "</div></div>";

    /* Clients & sectors */
    var mark = function (c) {
      return '<li class="mark">' + (c.logo ? '<img src="' + esc(c.logo) + '" alt="' + esc(c.name) + '" loading="lazy">' : '<span>' + esc(c.name) + "</span>") + "</li>";
    };
    var marks = S.clients.map(mark).join("");
    $("#clients").innerHTML =
      '<div class="wrap"><div class="sec-head"><h2>' + esc(T.clients.title) + "</h2><p>" + esc(T.clients.intro) + "</p></div></div>" +
      '<div class="marquee" aria-label="' + esc(T.clients.marquee) + '"><ul class="marquee-track">' + marks + '</ul><ul class="marquee-track marquee-copy" aria-hidden="true">' + marks + "</ul></div>" +
      '<div class="wrap"><div class="sectors">' + S.sectors.map(function (sc) {
        var x = sc[lang];
        var names = S.clients.filter(function (c) { return c.sector === sc.id; });
        return '<article class="sector"><div class="sector-top"><h3>' + esc(x.t) + '</h3><span class="num">' + names.length + "</span></div>" +
          '<ul class="sector-clients">' + names.map(function (c) { return "<li>" + esc(c.name) + "</li>"; }).join("") + "</ul>" +
          "<p>" + esc(x.d) + "</p>" +
          (x.tags.length ? '<ul class="sector-tags">' + x.tags.map(function (t) { return "<li>" + esc(t) + "</li>"; }).join("") + "</ul>" : "") +
          "</article>";
      }).join("") + "</div></div>";

    /* About */
    $("#about").innerHTML =
      '<div class="wrap"><div class="sec-head"><h2>' + esc(T.about.title) + "</h2></div>" +
      '<div class="about-grid"><div class="about-body">' + T.about.body.map(function (p) { return "<p>" + esc(p) + "</p>"; }).join("") + "</div>" +
      '<dl class="meta-list">' + T.about.meta.map(function (m) { return "<div><dt>" + esc(m.k) + "</dt><dd>" + esc(m.v) + "</dd></div>"; }).join("") + "</dl></div></div>";

    /* Showreel */
    var reelSec = $("#reel");
    if (S.reel && S.reel.src) {
      reelSec.hidden = false;
      reelSec.innerHTML =
        '<div class="wrap reel-grid">' +
          '<div class="reel-frame"><video id="reel-video" src="' + esc(S.reel.src) + '" poster="' + esc(S.reel.poster || "") + '" muted loop playsinline controls preload="metadata" width="1080" height="1920" aria-label="' + esc(T.reel.label) + '"></video></div>' +
          '<div class="reel-text"><p class="kicker">' + esc(T.reel.kicker) + "</p><h2>" + esc(T.reel.title) + '</h2><p class="lead">' + esc(T.reel.lead) + "</p>" +
            "<ul>" + T.reel.points.map(function (x) { return "<li>" + esc(x) + "</li>"; }).join("") + "</ul>" +
            '<div class="cta-row"><a class="btn btn-ghost" href="#work">' + esc(T.reel.cta) + ARROW + "</a></div></div>" +
        "</div>";
      watchReel();
    } else { reelSec.hidden = true; reelSec.innerHTML = ""; }

    /* Work */
    var chips = ['<button class="chip" type="button" data-f="all" aria-pressed="' + (filter === "all") + '">' + esc(T.work.filterAll) + "</button>"]
      .concat(S.categories.map(function (c) {
        return '<button class="chip" type="button" data-f="' + c.id + '" aria-pressed="' + (filter === c.id) + '">' + esc(c[lang]) + "</button>";
      })).join("");
    $("#work").innerHTML =
      '<div class="wrap"><div class="sec-head"><h2>' + esc(T.work.title) + "</h2><p>" + esc(T.work.intro) + "</p></div>" +
      (S.categories.length ? '<div class="filters" role="group" aria-label="' + esc(T.work.title) + '">' + chips + "</div>" : "") +
      '<div class="cases" id="cases"></div></div>';
    renderCases();

    /* Services + process */
    $("#services").innerHTML =
      '<div class="wrap"><div class="sec-head"><h2>' + esc(T.services.title) + "</h2><p>" + esc(T.services.intro) + "</p></div>" +
      '<div class="services">' + S.services.map(function (s) {
        var x = s[lang];
        return '<article class="service">' + icon(s.icon) + "<h3>" + esc(x.t) + "</h3><p>" + esc(x.d) + '</p><p class="gain">' + esc(x.gain) + "</p></article>";
      }).join("") + "</div>" +
      '<div class="process"><h3>' + esc(T.process.title) + '</h3><ol class="steps">' +
        T.process.steps.map(function (s) { return "<li><strong>" + esc(s.t) + "</strong><p>" + esc(s.d) + "</p></li>"; }).join("") +
      "</ol></div>" +
      '<div class="process"><h3>' + esc(T.skills.title) + '</h3><div class="skills">' +
        S.skills.map(function (g) {
          var items = g.items || pick(g, "items");
          return "<div><h3>" + esc(g[lang]) + "</h3><ul>" + items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul></div>";
        }).join("") +
      "</div></div></div>";

    /* Experience */
    $("#experience").innerHTML =
      '<div class="wrap"><div class="sec-head"><h2>' + esc(T.experience.title) + "</h2></div>" +
      '<div class="xp" id="xp">' +
        '<div class="xp-tabs" role="tablist" aria-label="' + esc(T.experience.title) + '">' + S.experience.map(function (j, i) {
          return '<button class="xp-tab" type="button" role="tab" id="xp-tab-' + i + '" aria-controls="xp-panel-' + i + '" aria-selected="' + (i === expIndex) + '" tabindex="' + (i === expIndex ? 0 : -1) + '" data-xp="' + i + '">' +
            '<span class="xp-tab-name">' + esc(j.tab || j[lang].org) + '</span><span class="xp-bar" aria-hidden="true"><i></i></span></button>';
        }).join("") + "</div>" +
        '<div class="xp-panels">' + S.experience.map(function (j, i) {
          var x = j[lang];
          var when = j.freelance ? esc(T.experience.freelance) : esc(x.from) + " — " + esc(x.to);
          var pts = x.points.slice(0, S.experienceMaxPoints || 4);
          return '<article class="xp-panel' + (i === expIndex ? " is-active" : "") + '" role="tabpanel" id="xp-panel-' + i + '" aria-labelledby="xp-tab-' + i + '"' + (i === expIndex ? "" : ' aria-hidden="true"') + ">" +
            '<div class="xp-head"><div><h3>' + esc(x.role) + '</h3><p class="org"><strong>' + esc(x.org) + "</strong> · " + esc(x.place) + '</p></div><span class="now">' + when + "</span></div>" +
            "<ul>" + pts.map(function (p) { return "<li>" + esc(p) + "</li>"; }).join("") + "</ul></article>";
        }).join("") + "</div></div>" +
      '<div class="edu"><h3>' + esc(T.experience.education) + "</h3><ul>" +
        S.education.map(function (e) { return "<li>" + esc(e[lang].t) + "<span>" + esc(e[lang].s) + "</span></li>"; }).join("") +
      "</ul></div></div>";

    /* Contact */
    $("#contact").innerHTML =
      '<div class="wrap"><h2>' + esc(T.contact.title) + '</h2><p class="lead">' + esc(T.contact.lead) + "</p>" +
      '<div class="contact-grid">' +
        '<div class="c-card"><span class="label">' + esc(T.contact.whatsapp) + '</span><span class="value" style="word-break:normal">' + esc(T.contact.whatsappHint) + "</span>" +
          '<div class="c-actions">' + C.whatsapp.map(function (w, i) {
            return '<a class="btn ' + "btn-primary" + '" href="' + waLink(T, w.number) + '" target="_blank" rel="noopener">' + WA_ICON + esc(w[lang]) + "</a>";
          }).join("") + "</div></div>" +
        '<div class="c-card"><span class="label">' + esc(T.contact.email) + '</span><span class="value" id="email-text">' + esc(C.email) + "</span>" +
          '<div class="c-actions"><a class="btn btn-outline-inv" href="mailto:' + esc(C.email) + '">' + esc(T.contact.email) + '</a><button class="btn btn-outline-inv" type="button" id="copy-email">' + esc(T.contact.copy) + "</button></div></div>" +
      "</div>" +
      '<div class="socials">' +
        (C.instagram ? '<a href="' + esc(C.instagram) + '" target="_blank" rel="noopener">' + esc(T.contact.instagram) + " · " + esc(C.instagramHandle) + "</a>" : "") +
        (C.linkedin ? '<a href="' + esc(C.linkedin) + '" target="_blank" rel="noopener">' + esc(T.contact.linkedin) + "</a>" : "") +
        (C.cvUrl ? '<a href="' + esc(C.cvUrl) + '" target="_blank" rel="noopener">' + esc(T.hero.ctaCv) + "</a>" : "") +
      "</div></div>";

    $("#footer").innerHTML = '<div class="wrap"><span>© <span class="num">' + new Date().getFullYear() + "</span> " + esc(T.footer) + '</span><a href="#top">↑</a></div>';
    document.dispatchEvent(new CustomEvent("site:rendered", { detail: { lang: lang } }));
  }

  // The reel plays (muted) only while it is on screen; visitors who prefer reduced motion start it themselves.
  var reelObserver = null;
  function watchReel() {
    var v = $("#reel-video");
    if (reelObserver) { reelObserver.disconnect(); reelObserver = null; }
    if (!v || !("IntersectionObserver" in window) || matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    reelObserver = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { var pr = v.play(); if (pr && pr.catch) pr.catch(function () {}); }
        else v.pause();
      });
    }, { threshold: 0.5 });
    reelObserver.observe(v);
  }

  function setExp(i, byUser) {
    var n = S.experience.length;
    var prev = expIndex;
    expIndex = ((i % n) + n) % n;
    document.querySelectorAll(".xp-tab").forEach(function (t, k) {
      t.setAttribute("aria-selected", String(k === expIndex));
      t.tabIndex = k === expIndex ? 0 : -1;
    });
    document.querySelectorAll(".xp-panel").forEach(function (p, k) {
      p.classList.toggle("is-active", k === expIndex);
      if (k === expIndex) p.removeAttribute("aria-hidden"); else p.setAttribute("aria-hidden", "true");
    });
    document.dispatchEvent(new CustomEvent("site:xp", { detail: { index: expIndex, prev: prev, byUser: !!byUser } }));
  }
  window.SiteXp = { go: setExp, next: function () { setExp(expIndex + 1, false); } };

  function sparkHTML(sp) {
    if (!sp) return "";
    var cap = sp[lang], body;
    if (sp.type === "share") {
      var pct = Math.round((sp.part / sp.total) * 100);
      body = '<div class="spark-share"><span class="spark-fill" style="width:' + pct + '%"></span></div>';
    } else {
      var max = Math.max.apply(null, sp.values), min = Math.min.apply(null, sp.values);
      var target = sp.best === "min" ? min : max;
      body = '<div class="spark-bars">' + sp.values.map(function (v) {
        var h = Math.max(4, Math.round((v / max) * 100));
        return '<span class="spark-bar' + (v === target ? " is-best" : "") + '" style="height:' + h + '%" title="' + esc(v + (sp.unit ? " " + sp.unit : "")) + '"></span>';
      }).join("") + "</div>";
    }
    var label = cap + (sp.values ? ": " + sp.values.join(", ") : "");
    return '<figure class="spark" role="img" aria-label="' + esc(label) + '">' + body + "<figcaption>" + esc(cap) + "</figcaption></figure>";
  }

  function matches(p) { return filter === "all" || p.categories.indexOf(filter) > -1; }

  function applyFilter() {
    var M = window.SiteMotion;
    var state = M && M.beforeFilter ? M.beforeFilter() : null;
    document.querySelectorAll("#cases .case").forEach(function (el) {
      var p = S.projects.find(function (q) { return q.id === el.dataset.id; });
      el.classList.toggle("is-out", !matches(p));
    });
    if (state) M.afterFilter(state);
  }

  function renderCases() {
    var T = S.t[lang];
    $("#cases").innerHTML = S.projects.map(function (p) {
      var x = p[lang];
      var m0 = p.metrics[0];
      var media = p.images.length
        ? '<img src="' + esc(p.images[0]) + '" alt="' + esc(T.work.labels.evidence + " — " + x.title) + '" loading="lazy" width="1600" height="800">'
        : '<div class="placeholder"><span class="num big">' + esc(m0.value) + "</span><span>" + esc(m0[lang]) + "</span></div>";
      return '<article class="case' + (matches(p) ? "" : " is-out") + '" data-id="' + esc(p.id) + '">' +
        '<div class="case-media">' + media + "</div>" +
        '<div class="case-body">' +
          '<div class="case-tags"><span>' + esc(x.platform) + "</span><span>" + esc(x.sector) + "</span></div>" +
          "<h3>" + esc(x.title) + "</h3>" +
          sparkHTML(p.spark) +
          '<div class="case-metrics">' + p.metrics.map(metricHTML).join("") + "</div>" +
          '<div class="case-foot"><span>' + esc(x.period !== "—" ? x.period : x.currency) + '</span><button class="case-open" type="button" data-case="' + esc(p.id) + '">' + esc(T.work.open) + ARROW + "</button></div>" +
        "</div></article>";
    }).join("");
    document.dispatchEvent(new CustomEvent("site:cases"));
  }

  function openCase(id) {
    var T = S.t[lang], L = T.work.labels;
    var p = S.projects.find(function (q) { return q.id === id; });
    if (!p) return;
    var x = p[lang];
    var dlg = $("#case-dialog");
    var li = function (arr) { return "<ul>" + arr.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul>"; };
    dlg.innerHTML =
      '<div class="dlg-head"><div><div class="case-tags" style="margin-bottom:8px"><span>' + esc(x.sector) + '</span></div><h3 id="dlg-title">' + esc(x.title) + '</h3></div>' +
        '<button class="dlg-close" type="button" aria-label="' + esc(T.work.close) + '"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" aria-hidden="true"><path d="M6 6l12 12M18 6 6 18"/></svg></button></div>' +
      '<div class="dlg-body">' +
        '<dl class="dlg-facts"><div><dt>' + esc(L.platform) + "</dt><dd>" + esc(x.platform) + "</dd></div><div><dt>" + esc(L.period) + "</dt><dd>" + esc(x.period) + "</dd></div><div><dt>" + esc(L.currency) + "</dt><dd>" + esc(x.currency) + "</dd></div></dl>" +
        '<div class="case-metrics">' + p.metrics.map(metricHTML).join("") + "</div>" +
        '<div class="dlg-two"><div class="dlg-block"><h4>' + esc(L.goal) + "</h4><p>" + esc(x.goal) + '</p></div><div class="dlg-block"><h4>' + esc(L.challenge) + "</h4><p>" + esc(x.challenge) + "</p></div></div>" +
        '<div class="dlg-block"><h4>' + esc(L.role) + "</h4><p>" + esc(x.role) + "</p></div>" +
        '<div class="dlg-two"><div class="dlg-block"><h4>' + esc(L.execution) + "</h4>" + li(x.execution) + '</div><div class="dlg-block dlg-results"><h4>' + esc(L.results) + "</h4>" + li(x.results) + "</div></div>" +
        p.images.map(function (src) {
          return '<figure class="dlg-shot" style="margin:0"><div class="scroll"><img src="' + esc(src) + '" alt="' + esc(L.evidence) + '" loading="lazy"></div><figcaption>' + esc(L.evidence) + "</figcaption></figure>";
        }).join("") +
      "</div>";
    dlg.setAttribute("aria-labelledby", "dlg-title");
    if (typeof dlg.showModal === "function") dlg.showModal(); else dlg.setAttribute("open", "");
    if (window.SiteMotion && window.SiteMotion.openDialog) window.SiteMotion.openDialog(dlg);
    $(".dlg-close", dlg).focus();
  }

  /* Events (delegated, survive re-render) */
  document.addEventListener("click", function (e) {
    var t = e.target.closest("button, a");
    if (!t) return;
    if (t.id === "lang-btn") {
      lang = lang === "ar" ? "en" : "ar";
      try { localStorage.setItem("mm-lang", lang); } catch (err) {}
      render();
      return;
    }
    if (t.id === "menu-btn") {
      var open = $("#nav").classList.toggle("open");
      t.setAttribute("aria-expanded", String(open));
      return;
    }
    if (t.closest("#nav")) { $("#nav").classList.remove("open"); $("#menu-btn").setAttribute("aria-expanded", "false"); }
    if (t.dataset.f) {
      filter = t.dataset.f;
      document.querySelectorAll(".chip").forEach(function (c) { c.setAttribute("aria-pressed", String(c.dataset.f === filter)); });
      applyFilter();
      return;
    }
    if (t.dataset.xp) { setExp(Number(t.dataset.xp), true); return; }
    if (t.dataset.case) { openCase(t.dataset.case); return; }
    if (t.classList.contains("dlg-close")) { closeDlg(); return; }
    if (t.id === "copy-email") {
      var T = S.t[lang];
      var done = function () { t.textContent = T.contact.copied; setTimeout(function () { t.textContent = T.contact.copy; }, 1800); };
      var fallback = function () {
        var r = document.createRange(); r.selectNodeContents($("#email-text"));
        var sel = getSelection(); sel.removeAllRanges(); sel.addRange(r);
      };
      try { navigator.clipboard.writeText(S.contact.email).then(done, fallback); } catch (err) { fallback(); }
    }
  });
  function closeDlg() {
    var dlg = $("#case-dialog");
    var M = window.SiteMotion;
    if (M && M.closeDialog) M.closeDialog(dlg, function () { dlg.close(); }); else dlg.close();
  }
  $("#case-dialog").addEventListener("click", function (e) { if (e.target === this) closeDlg(); });

  document.addEventListener("keydown", function (e) {
    var tab = e.target.closest && e.target.closest(".xp-tab");
    if (!tab || (e.key !== "ArrowLeft" && e.key !== "ArrowRight")) return;
    var rtl = document.documentElement.dir === "rtl";
    var step = (e.key === "ArrowRight") !== rtl ? 1 : -1;
    setExp(expIndex + step, true);
    var el = document.querySelector('.xp-tab[aria-selected="true"]');
    if (el) el.focus();
    e.preventDefault();
  });

  var header = $(".site-header");
  addEventListener("scroll", function () { header.classList.toggle("scrolled", scrollY > 8); }, { passive: true });

  render();
})();
