/* Motion layer (GSAP + ScrollTrigger). Loaded before main.js; reacts to its render events.
   1) Count-up numbers   2) Rotating results chip by the photo   3) Scroll reveals.
   If GSAP fails to load or the visitor prefers reduced motion, the page stays static and complete. */
(function () {
  "use strict";
  var gsap = window.gsap;
  if (!gsap) return;
  if (window.ScrollTrigger) gsap.registerPlugin(window.ScrollTrigger);
  var ST = window.ScrollTrigger;
  var reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
  var tickerTimer = null;
  var revealTriggers = [];
  var caseTriggers = [];

  /* ---------- 1. Count-up ---------- */
  // "375K+" -> {pre:"", n:375, dec:0, post:"K+"}; "$0.09" -> {pre:"$", n:0.09, dec:2}
  function parse(str) {
    var m = /^([^\d]*)([\d,]*\.?\d+)(.*)$/.exec(str.trim());
    if (!m) return null;
    var raw = m[2].replace(/,/g, "");
    return { pre: m[1], n: parseFloat(raw), dec: (raw.split(".")[1] || "").length, comma: m[2].indexOf(",") > -1, post: m[3] };
  }
  function fmt(p, v) {
    var s = v.toFixed(p.dec);
    if (p.comma) s = Number(s).toLocaleString("en-US", { minimumFractionDigits: p.dec, maximumFractionDigits: p.dec });
    return p.pre + s + p.post;
  }
  function countUp(el, delay) {
    var node = el.firstChild;
    if (!node || node.nodeType !== 3) return null;
    var final = node.nodeValue;
    var p = parse(final);
    if (!p || reduce) return null;
    var o = { v: 0 };
    node.nodeValue = fmt(p, 0);
    return gsap.to(o, {
      v: p.n, duration: p.n > 99 ? 1.6 : 1.2, delay: delay || 0, ease: "power3.out",
      onUpdate: function () { node.nodeValue = fmt(p, o.v); },
      onComplete: function () { node.nodeValue = final; },
    });
  }

  function heroCounters() {
    document.querySelectorAll(".facts .fact .num").forEach(function (el, i) { countUp(el, 0.35 + i * 0.12); });
  }

  function caseCounters() {
    caseTriggers.forEach(function (t) { t.kill(); });
    caseTriggers = [];
    if (reduce || !ST) return;
    document.querySelectorAll("#cases .case").forEach(function (card) {
      var nums = card.querySelectorAll(".case-metrics .num, .placeholder .num");
      // hold the final values until the card scrolls into view
      var finals = Array.prototype.map.call(nums, function (n) { return n.firstChild && n.firstChild.nodeValue; });
      caseTriggers.push(ST.create({
        trigger: card, start: "top 85%", once: true,
        onEnter: function () {
          nums.forEach(function (n, i) { if (n.firstChild) n.firstChild.nodeValue = finals[i]; countUp(n, i * 0.1); });
        },
      }));
    });
    // 4. mini charts draw themselves when the card enters view
    document.querySelectorAll("#cases .spark").forEach(function (sp) {
      var bars = sp.querySelectorAll(".spark-bar");
      var fill = sp.querySelector(".spark-fill");
      if (bars.length) gsap.set(bars, { scaleY: 0, transformOrigin: "50% 100%" });
      if (fill) gsap.set(fill, { scaleX: 0, transformOrigin: document.documentElement.dir === "rtl" ? "100% 50%" : "0% 50%" });
      caseTriggers.push(ST.create({
        trigger: sp, start: "top 92%", once: true,
        onEnter: function () {
          if (bars.length) gsap.to(bars, { scaleY: 1, duration: 0.7, stagger: 0.05, ease: "back.out(1.6)", clearProps: "transform" });
          if (fill) gsap.to(fill, { scaleX: 1, duration: 1.1, ease: "power3.out", clearProps: "transform" });
        },
      }));
    });
    gsap.fromTo("#cases .case:not(.is-out)", { y: 24, opacity: 0.25 }, { y: 0, opacity: 1, duration: 0.6, stagger: 0.08, ease: "power2.out", clearProps: "transform,opacity" });
  }

  /* ---------- 5. Filter (Flip) + dialog ---------- */
  var Flip = window.Flip;
  if (Flip) gsap.registerPlugin(Flip);
  window.SiteMotion = {
    beforeFilter: function () {
      if (reduce || !Flip) return null;
      return Flip.getState("#cases .case");
    },
    afterFilter: function (state) {
      Flip.from(state, {
        duration: 0.55, ease: "power3.inOut", absolute: true, stagger: 0.03,
        onEnter: function (els) { return gsap.fromTo(els, { opacity: 0, scale: 0.94 }, { opacity: 1, scale: 1, duration: 0.45, delay: 0.1, clearProps: "transform,opacity" }); },
        onLeave: function (els) { return gsap.to(els, { opacity: 0, scale: 0.94, duration: 0.3 }); },
        onComplete: function () { gsap.set("#cases .case", { clearProps: "all" }); if (ST) ST.refresh(); },
      });
    },
    openDialog: function (dlg) {
      if (reduce) return;
      gsap.fromTo(dlg, { y: 28, opacity: 0, scale: 0.97 }, { y: 0, opacity: 1, scale: 1, duration: 0.4, ease: "power3.out", clearProps: "transform,opacity" });
      gsap.fromTo(dlg.querySelectorAll(".dlg-body > *"), { y: 16, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45, stagger: 0.06, delay: 0.12, ease: "power2.out", clearProps: "transform,opacity" });
    },
    closeDialog: function (dlg, done) {
      if (reduce) return done();
      gsap.to(dlg, { y: 16, opacity: 0, duration: 0.2, ease: "power2.in", onComplete: function () { done(); gsap.set(dlg, { clearProps: "transform,opacity" }); } });
    },
  };

  /* ---------- 2. Rotating results chip ---------- */
  function ticker(lang) {
    clearInterval(tickerTimer);
    var items = (window.SITE && window.SITE.heroTicker) || [];
    var chip = document.querySelector(".ledger-chip");
    if (!chip || items.length < 2) return;
    var dot = chip.querySelector(".live");
    if (dot && !reduce) gsap.fromTo(dot, { scale: 1, opacity: 1 }, { scale: 1.8, opacity: 0.35, duration: 1.1, repeat: -1, yoyo: true, ease: "sine.inOut" });
    var i = 0;
    var label = chip.querySelector(".t-label");
    var value = chip.querySelector(".t-value");
    function set(k) {
      label.textContent = k[lang];
      var unit = lang === "ar" ? k.unitAr : k.unitEn;
      value.innerHTML = "";
      value.appendChild(document.createTextNode(k.value));
      if (unit) { var s = document.createElement("small"); s.textContent = unit; value.appendChild(s); }
    }
    tickerTimer = setInterval(function () {
      if (document.hidden) return;
      i = (i + 1) % items.length;
      if (reduce) { set(items[i]); return; }
      gsap.timeline()
        .to([label, value], { y: -10, opacity: 0, duration: 0.28, ease: "power2.in", stagger: 0.04 })
        .add(function () { set(items[i]); })
        .fromTo([label, value], { y: 10, opacity: 0 }, { y: 0, opacity: 1, duration: 0.4, ease: "power2.out", stagger: 0.05 })
        .add(function () { countUp(value, 0); }, "<");
    }, 3600);
  }

  /* ---------- 3. Scroll reveals ---------- */
  function reveals() {
    revealTriggers.forEach(function (t) { t.kill(); });
    revealTriggers = [];
    if (reduce || !ST) return;
    var groups = [
      ["#clients .sec-head, #clients .marquee, #clients .sector"],
      ["#about .sec-head, #about .about-body > *, #about .meta-list > div"],
      ["#reel .reel-frame, #reel .reel-text > *"],
      ["#work .sec-head, #work .filters"],
      ["#services .sec-head, #services .service"],
      ["#services .process h3, #services .steps li"],
      ["#services .skills > div"],
      ["#experience .sec-head, #experience .xp, #experience .edu li"],
      ["#contact h2, #contact .lead, #contact .c-card, #contact .socials"],
    ];
    groups.forEach(function (g) {
      var els = gsap.utils.toArray(g[0]);
      if (!els.length) return;
      // Content is never fully hidden: it starts dimmed and shifted, then settles.
      gsap.set(els, { y: 26, opacity: 0.2 });
      ST.batch(els, {
        start: "top 90%", once: true,
        onEnter: function (batch) {
          gsap.to(batch, { y: 0, opacity: 1, duration: 0.7, stagger: 0.07, ease: "power3.out", overwrite: true, clearProps: "transform,opacity" });
        },
      }).forEach(function (t) { revealTriggers.push(t); });
    });
    // Anything already on screen (e.g. after a language switch mid-page) settles right away.
    ST.refresh();
  }

  /* ---------- 6. Small details: progress line, nav indicator, magnetic buttons ---------- */
  var progress = null;
  var navTriggers = [];
  var activeId = null;

  function progressLine() {
    var header = document.querySelector(".site-header");
    if (!header || !ST) return;
    if (!progress) {
      progress = document.createElement("div");
      progress.className = "scroll-progress";
      progress.setAttribute("aria-hidden", "true");
      header.appendChild(progress);
      gsap.set(progress, { scaleX: 0 });
      gsap.to(progress, { scaleX: 1, ease: "none", scrollTrigger: { start: 0, end: "max", scrub: reduce ? true : 0.3 } });
    }
    progress.style.transformOrigin = document.documentElement.dir === "rtl" ? "100% 50%" : "0% 50%";
  }

  function navIndicator() {
    navTriggers.forEach(function (t) { t.kill(); });
    navTriggers = [];
    var nav = document.querySelector("#nav");
    if (!nav || !ST) return;
    var ind = document.createElement("span");
    ind.className = "nav-ind";
    ind.setAttribute("aria-hidden", "true");
    nav.appendChild(ind);
    function place(animate) {
      var link = activeId && nav.querySelector('a[href="#' + activeId + '"]');
      nav.querySelectorAll("a").forEach(function (a) {
        if (a === link) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
      });
      if (!link || getComputedStyle(ind).display === "none") { gsap.to(ind, { opacity: 0, duration: 0.2 }); return; }
      var to = { x: link.offsetLeft + 10, width: Math.max(0, link.offsetWidth - 20), opacity: 1 };
      if (animate && !reduce) gsap.to(ind, Object.assign({ duration: 0.45, ease: "power3.out", overwrite: true }, to));
      else gsap.set(ind, to);
    }
    ["clients", "about", "work", "services", "experience", "contact"].forEach(function (id) {
      navTriggers.push(ST.create({
        trigger: "#" + id, start: "top 45%", end: "bottom 45%",
        onToggle: function (self) {
          if (self.isActive) { activeId = id; place(true); }
          else if (activeId === id) { activeId = null; place(true); }
        },
      }));
    });
    place(false);
    window.removeEventListener("resize", navIndicator._onResize);
    navIndicator._onResize = function () { place(false); };
    window.addEventListener("resize", navIndicator._onResize);
  }

  function magnetic() {
    if (reduce || !window.matchMedia("(hover: hover) and (pointer: fine)").matches) return;
    document.querySelectorAll(".btn:not(.btn-link), .lang-btn").forEach(function (el) {
      if (el._magnetic) return;
      el._magnetic = true;
      el.classList.add("magnetic");
      var xTo = gsap.quickTo(el, "x", { duration: 0.35, ease: "power3.out" });
      var yTo = gsap.quickTo(el, "y", { duration: 0.35, ease: "power3.out" });
      el.addEventListener("pointermove", function (e) {
        var r = el.getBoundingClientRect();
        xTo((e.clientX - (r.left + r.width / 2)) * 0.28);
        yTo((e.clientY - (r.top + r.height / 2)) * 0.4);
      });
      el.addEventListener("pointerleave", function () {
        gsap.to(el, { x: 0, y: 0, duration: 0.7, ease: "elastic.out(1, 0.45)", overwrite: true });
      });
    });
  }

  /* ---------- 7. Ideas adapted from the "awesome-opus5-5-videos" prompt pack ----------
     word-stagger headline, cursor "x-ray" spotlight, solid tilt toward the cursor, scroll-driven steps */
  var fine = window.matchMedia("(hover: hover) and (pointer: fine)").matches;
  var stepTriggers = [];
  var xrayDrift = null;

  function headline() {
    var h = document.querySelector(".hero h1");
    if (!h || reduce) return;
    var text = h.textContent;
    h.setAttribute("aria-label", text);
    h.innerHTML = text.split(/\s+/).map(function (w) {
      return '<span class="w" aria-hidden="true"><span class="wi">' + w.replace(/[&<>]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;" }[c]; }) + "</span></span>";
    }).join(" ");
    gsap.from(h.querySelectorAll(".wi"), { yPercent: 115, duration: 0.95, stagger: 0.07, ease: "power4.out", delay: 0.1, clearProps: "transform" });
  }

  // A layer of real campaign numbers sits behind the contact band; the cursor reveals it like a torch.
  function xray() {
    var sec = document.querySelector("#contact");
    if (!sec) return;
    if (xrayDrift) { xrayDrift.kill(); xrayDrift = null; }
    var tokens = [];
    (window.SITE.projects || []).forEach(function (p) {
      p.metrics.forEach(function (m) { tokens.push(m.value + (m.unitEn ? " " + m.unitEn : "") + " " + m.en); });
    });
    if (!tokens.length) return;
    var layer = document.createElement("div");
    layer.className = "xray";
    layer.setAttribute("aria-hidden", "true");
    var rows = "";
    for (var r = 0; r < 16; r++) {
      var k = (r * 5) % tokens.length;
      var line = tokens.slice(k).concat(tokens.slice(0, k)).join("   ·   ");
      rows += '<div class="xray-row">' + line + "   ·   " + line + "</div>";
    }
    layer.innerHTML = rows;
    sec.insertBefore(layer, sec.firstChild);
    var pos = { x: 70, y: 40 };
    function apply() { layer.style.setProperty("--mx", pos.x + "%"); layer.style.setProperty("--my", pos.y + "%"); }
    apply();
    if (reduce) return;
    if (fine) {
      var xTo = gsap.quickTo(pos, "x", { duration: 0.5, ease: "power3.out", onUpdate: apply });
      var yTo = gsap.quickTo(pos, "y", { duration: 0.5, ease: "power3.out", onUpdate: apply });
      sec.addEventListener("pointermove", function (e) {
        var b = sec.getBoundingClientRect();
        xTo(((e.clientX - b.left) / b.width) * 100);
        yTo(((e.clientY - b.top) / b.height) * 100);
      });
    } else {
      // touch screens: the torch drifts slowly on its own
      xrayDrift = gsap.timeline({ repeat: -1, yoyo: true, onUpdate: apply })
        .to(pos, { x: 25, y: 65, duration: 6, ease: "sine.inOut" })
        .to(pos, { x: 75, y: 25, duration: 6, ease: "sine.inOut" });
    }
  }

  // Cards and the portrait behave like solid objects leaning toward the cursor. Smooth, never bouncy.
  function tilt() {
    if (reduce || !fine) return;
    document.querySelectorAll("#cases .case, .portrait img").forEach(function (el) {
      if (el._tilt) return;
      el._tilt = true;
      el.classList.add("tilt");
      var max = el.tagName === "IMG" ? 9 : 4.5;
      gsap.set(el, { transformPerspective: 900 });
      var rx = gsap.quickTo(el, "rotationX", { duration: 0.5, ease: "power3.out" });
      var ry = gsap.quickTo(el, "rotationY", { duration: 0.5, ease: "power3.out" });
      el.addEventListener("pointermove", function (e) {
        var b = el.getBoundingClientRect();
        ry(((e.clientX - b.left) / b.width - 0.5) * 2 * max);
        rx(-((e.clientY - b.top) / b.height - 0.5) * 2 * max);
      });
      el.addEventListener("pointerleave", function () { rx(0); ry(0); });
    });
  }

  // The five steps fill in order as the visitor scrolls through them.
  function stepsProgress() {
    stepTriggers.forEach(function (t) { t.kill(); });
    stepTriggers = [];
    var steps = gsap.utils.toArray(".steps li");
    if (!steps.length || !ST || reduce) return;
    var rtl = document.documentElement.dir === "rtl";
    var bars = steps.map(function (li) {
      var b = document.createElement("span");
      b.className = "step-bar";
      b.setAttribute("aria-hidden", "true");
      li.appendChild(b);
      return b;
    });
    gsap.set(bars, { scaleX: 0, transformOrigin: rtl ? "100% 50%" : "0% 50%" });
    var tl = gsap.timeline({ scrollTrigger: { trigger: ".steps", start: "top 82%", end: "bottom 55%", scrub: 0.5 } });
    bars.forEach(function (b) { tl.to(b, { scaleX: 1, duration: 1, ease: "none" }); });
    stepTriggers.push(tl.scrollTrigger);
  }

  /* ---------- 8. Experience: one box that rotates through the roles ---------- */
  var xpTween = null, xpTrig = null, xpAuto = true;
  var XP_SECONDS = 7;

  function xpBar() {
    if (xpTween) { xpTween.kill(); xpTween = null; }
    var fills = document.querySelectorAll(".xp-bar i");
    gsap.set(fills, { scaleX: 0, transformOrigin: document.documentElement.dir === "rtl" ? "100% 50%" : "0% 50%" });
    var active = document.querySelector('.xp-tab[aria-selected="true"] .xp-bar i');
    if (!active) return;
    if (!xpAuto || reduce) { gsap.set(active, { scaleX: 1 }); return; }
    xpTween = gsap.to(active, { scaleX: 1, duration: XP_SECONDS, ease: "none", paused: !(xpTrig && xpTrig.isActive), onComplete: function () { window.SiteXp.next(); } });
  }

  function xpSetup() {
    if (xpTrig) { xpTrig.kill(); xpTrig = null; }
    var box = document.querySelector("#xp");
    if (!box) return;
    if (ST) xpTrig = ST.create({ trigger: box, start: "top 85%", end: "bottom 15%", onToggle: function (self) { if (xpTween) xpTween.paused(!self.isActive); } });
    box.addEventListener("pointerenter", function () { if (xpTween) xpTween.pause(); });
    box.addEventListener("pointerleave", function () { if (xpTween && xpTrig && xpTrig.isActive) xpTween.play(); });
    box.addEventListener("focusin", function () { if (xpTween) xpTween.pause(); });
    xpBar();
  }

  document.addEventListener("site:xp", function (e) {
    if (e.detail.byUser) xpAuto = false; // once the visitor picks a role, stop rotating
    xpBar();
    if (reduce) return;
    var panel = document.querySelector(".xp-panel.is-active");
    if (!panel) return;
    var dir = document.documentElement.dir === "rtl" ? -1 : 1;
    gsap.fromTo(panel.querySelector(".xp-head"), { x: 28 * dir, opacity: 0 }, { x: 0, opacity: 1, duration: 0.5, ease: "power3.out", clearProps: "transform,opacity" });
    gsap.fromTo(panel.querySelectorAll("li"), { y: 14, opacity: 0 }, { y: 0, opacity: 1, duration: 0.45, stagger: 0.07, delay: 0.08, ease: "power2.out", clearProps: "transform,opacity" });
  });

  /* ---------- 9. Clients marquee ---------- */
  var marqueeTween = null;
  function marquee() {
    if (marqueeTween) { marqueeTween.kill(); marqueeTween = null; }
    var box = document.querySelector(".marquee");
    if (!box || reduce) return;
    box.classList.add("is-running");
    var tracks = box.querySelectorAll(".marquee-track");
    // the two identical tracks sit side by side; sliding one track-width loops seamlessly
    marqueeTween = gsap.fromTo(tracks, { xPercent: 0 }, { xPercent: -100, duration: 26, ease: "none", repeat: -1 });
    box.addEventListener("pointerenter", function () { gsap.to(marqueeTween, { timeScale: 0.15, duration: 0.4 }); });
    box.addEventListener("pointerleave", function () { gsap.to(marqueeTween, { timeScale: 1, duration: 0.4 }); });
  }

  document.addEventListener("site:rendered", function (e) {
    marquee();
    xpSetup();
    heroCounters();
    ticker(e.detail.lang);
    reveals();
    progressLine();
    navIndicator();
    magnetic();
    headline();
    xray();
    tilt();
    stepsProgress();
  });
  document.addEventListener("site:cases", tilt);
  document.addEventListener("site:cases", caseCounters);
})();
