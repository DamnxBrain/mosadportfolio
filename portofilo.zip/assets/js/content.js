/* ==========================================================================
   محتوى الموقع — كل النصوص والمشاريع وبيانات التواصل في هذا الملف فقط.
   SITE CONTENT — edit everything (texts, projects, contacts) here only.

   - كل نص له نسختان: ar و en.
   - لإضافة مشروع: انسخ أي عنصر داخل projects وعدّل بياناته وصورته.
   - لإخفاء زر السيرة الذاتية: اجعل cvUrl = "" (فارغ).
   - الصور داخل مجلد assets/img
   ========================================================================== */

window.SITE = {
  defaultLang: "ar",

  contact: {
    email: "mo.mosad.careers@gmail.com",
    // أرقام واتساب (لا تظهر كنص في الموقع، فقط كأزرار). الصيغة الدولية بدون + أو أصفار
    whatsapp: [
      { number: "201061450430", ar: "واتساب مصر", en: "WhatsApp Egypt" },
      { number: "971547292911", ar: "واتساب الإمارات", en: "WhatsApp UAE" },
    ],
    instagram: "https://www.instagram.com/scalewithmosad/",
    instagramHandle: "@scalewithmosad",
    linkedin: "https://www.linkedin.com/in/mohamed-mosad2",
    cvUrl: "", // ضع "assets/docs/Mohamed_Mosad_CV.pdf" لإظهار زر السيرة الذاتية
  },

  photo: "assets/img/mohamed.webp",

  /* فيديو الـ Showreel — يظهر قبل قسم الأعمال. اجعل src = "" لإخفاء القسم */
  reel: { src: "assets/video/mohamed-mosad-showreel.mp4", poster: "assets/video/showreel-poster.jpg" },

  /* البطاقة المتحركة بجانب الصورة — تتبدّل بين أفضل النتائج */
  heroTicker: [
    { value: "$0.09", unitAr: "", unitEn: "", ar: "أقل تكلفة نقرة · Meta", en: "Lowest cost per click · Meta" },
    { value: "10.4M", unitAr: "", unitEn: "", ar: "ظهور · حساب Meta واحد", en: "Impressions · one Meta account" },
    { value: "951", unitAr: "", unitEn: "", ar: "نقرة لأفضل إعلان · سيارات", en: "Clicks, top ad · Automotive" },
  ],

  /* ---------------- نصوص الواجهة ---------------- */
  t: {
    ar: {
      name: "محمد مسعد",
      role: "Media Buyer · تسويق بالأداء",
      nav: { clients: "العملاء", about: "نبذة", work: "الأعمال", services: "الخدمات", experience: "الخبرات", contact: "تواصل" },
      langSwitch: "English",
      hero: {
        kicker: "ميديا باير — مصر والخليج",
        title: "إعلانات ممولة تُقاس بتكلفة العميل، لا بعدد المشاهدات.",
        lead: "أدير حملات Meta وسناب شات وتيك توك للعيادات والأنشطة المحلية في الإمارات ومصر، وأربطها بقمع حجز عبر واتساب حتى تعرف كم كلّفك كل استفسار وكل موعد.",
        ctaWork: "شاهد أعمالي",
        ctaContact: "تواصل معي",
        ctaCv: "السيرة الذاتية (PDF)",
      },
      facts: [
        { value: "3", unit: "سنوات", label: "خبرة في شراء الإعلانات" },
        { value: "375K+", unit: "د.إ", label: "إجمالي ميزانيات إعلانية أدرتها" },
        { value: "3", unit: "قطاعات", label: "تجميل · سيارات · عقارات" },
        { value: "3", unit: "منصات", label: "Meta · Snapchat · TikTok" },
      ],
      clients: {
        title: "عملاء اشتغلت معهم",
        intro: "علامات في ثلاثة قطاعات مختلفة، بين الإمارات ومصر.",
        marquee: "عملاء اشتغلت معهم",
        sectorsTitle: "القطاعات",
      },
      reel: {
        kicker: "Showreel",
        title: "شغلي في 15 ثانية",
        lead: "ملخص سريع للأرقام: الميزانيات التي أدرتها، المنصات، وأبرز نتائج الحملات.",
        points: ["375K+ د.إ ميزانيات إعلانية", "3 قطاعات: تجميل، سيارات، عقارات", "نتائج من لوحات الإعلانات مباشرة"],
        cta: "شاهد دراسات الحالة",
        label: "فيديو Showreel لأعمال محمد مسعد",
      },
      about: {
        title: "نبذة عني",
        body: [
          "أنا محمد مسعد، ميديا باير متخصص في الاستحواذ المدفوع للعيادات التجميلية وعيادات الأسنان في الإمارات. أبني الحملات حسب الخدمة والفرع، وأوجّهها إلى واتساب، وأحكم على كل درهم بتكلفة المحادثة وعدد الحجوزات المؤكدة.",
          "بدأت في وكالة إبداعية بالقاهرة أدير حسابات Meta وسناب شات وتيك توك لعملاء مختلفين، ثم انتقلت للعمل داخل مجموعات عيادات متعددة الفروع في دبي وأبوظبي والشارقة ورأس الخيمة. أكتب الإعلانات وسكربتات الفيديو بالعربية بنفسي، وأسلّم تقارير أداء واضحة للإدارة.",
        ],
        meta: [
          { k: "المقر", v: "الإمارات" },
          { k: "الأسواق", v: "الإمارات · الخليج · مصر" },
          { k: "اللغات", v: "العربية (الأم) · الإنجليزية (بطلاقة)" },
          { k: "التخصص", v: "العيادات التجميلية والأسنان · السيارات · العقارات" },
        ],
      },
      work: {
        title: "أعمال مختارة",
        intro: "نتائج من حسابات إعلانية حقيقية، بالعملة والفترة كما تظهر في لوحة الإعلانات. أسماء العملاء محجوبة احترامًا للخصوصية.",
        filterAll: "الكل",
        open: "تفاصيل الحالة",
        labels: { goal: "الهدف", challenge: "التحدي", role: "دوري", execution: "التنفيذ", results: "النتائج", period: "الفترة", currency: "العملة", platform: "المنصة", evidence: "لقطة من لوحة الإعلانات" },
        close: "إغلاق",
      },
      services: {
        title: "الخدمات",
        intro: "ماذا أقدم، وماذا تستفيد منه.",
      },
      process: {
        title: "طريقة العمل",
        steps: [
          { t: "مراجعة الحساب", d: "أراجع الحساب الحالي: الأهداف، هيكل الحملات، التتبع، والإعلانات التي نجحت سابقًا." },
          { t: "الهيكلة والخطة", d: "أقسّم الحملات حسب الخدمة والفرع، وأوزّع الميزانية الشهرية على المنصات." },
          { t: "الإطلاق والاختبار", d: "أطلق عدة إعلانات لكل خدمة بنصوص عربية مختلفة وأقارنها على مستوى الإعلان." },
          { t: "التحسين وإعادة التوزيع", d: "أوقف الأضعف وأنقل الميزانية للأفضل حسب تكلفة النتيجة، لا حسب الانطباع." },
          { t: "التقرير", d: "تقرير دوري بالعربية: تكلفة المحادثة، جودة العملاء، والحجوزات المؤكدة." },
        ],
      },
      skills: { title: "المهارات والأدوات" },
      experience: { title: "الخبرات السابقة", education: "التعليم والشهادات", present: "حتى الآن", freelance: "فريلانس" },
      contact: {
        title: "عندك حملة تريد تكبيرها، أو حساب يحتاج مراجعة؟",
        lead: "أرسل لي على واتساب أو البريد: النشاط، المدينة، والميزانية الشهرية التقريبية. أرد عليك بخطة مبدئية.",
        whatsapp: "واتساب",
        whatsappHint: "اختر الرقم الأقرب لك، وستفتح المحادثة مباشرة.",
        email: "البريد الإلكتروني",
        copy: "نسخ",
        copied: "تم النسخ",
        instagram: "إنستجرام",
        linkedin: "لينكدإن",
        waMessage: "مرحبًا محمد، أريد الحديث عن حملة إعلانية.",
      },
      footer: "محمد مسعد — Media Buyer",
      skipLink: "تخطَّ إلى المحتوى",
    },

    en: {
      name: "Mohamed Mosad",
      role: "Media Buyer · Performance Marketing",
      nav: { clients: "Clients", about: "About", work: "Work", services: "Services", experience: "Experience", contact: "Contact" },
      langSwitch: "العربية",
      hero: {
        kicker: "Media Buyer — Egypt & the Gulf",
        title: "Paid ads judged by cost per customer, not by views.",
        lead: "I run Meta, Snapchat and TikTok campaigns for clinics and local businesses in the UAE and Egypt, and connect them to a WhatsApp booking funnel so you know what every inquiry and appointment cost.",
        ctaWork: "View my work",
        ctaContact: "Contact me",
        ctaCv: "Download CV (PDF)",
      },
      facts: [
        { value: "3", unit: "years", label: "in media buying" },
        { value: "375K+", unit: "AED", label: "total ad spend managed" },
        { value: "3", unit: "sectors", label: "Aesthetics · Automotive · Real estate" },
        { value: "3", unit: "platforms", label: "Meta · Snapchat · TikTok" },
      ],
      clients: {
        title: "Clients I've worked with",
        intro: "Brands across three different sectors, between the UAE and Egypt.",
        marquee: "Clients I've worked with",
        sectorsTitle: "Sectors",
      },
      reel: {
        kicker: "Showreel",
        title: "My work in 15 seconds",
        lead: "A quick summary in numbers: budgets managed, platforms, and top campaign results.",
        points: ["AED 375K+ in ad budgets", "3 sectors: aesthetics, automotive, real estate", "Results straight from the ads managers"],
        cta: "See the case studies",
        label: "Showreel video of Mohamed Mosad's work",
      },
      about: {
        title: "About me",
        body: [
          "I'm Mohamed Mosad, a media buyer specialising in paid acquisition for aesthetic and dental clinics in the UAE. I structure campaigns by service and branch, route them to WhatsApp, and judge every dirham by cost per conversation and confirmed bookings.",
          "I started at a creative agency in Cairo, running Meta, Snapchat and TikTok accounts for different clients, then moved in-house with multi-branch clinic groups in Dubai, Abu Dhabi, Sharjah and Ras Al Khaimah. I write the Arabic ad copy and video scripts myself and deliver clear performance reports to management.",
        ],
        meta: [
          { k: "Based in", v: "UAE" },
          { k: "Markets", v: "UAE · GCC · Egypt" },
          { k: "Languages", v: "Arabic (native) · English (fluent)" },
          { k: "Focus", v: "Aesthetic & dental clinics · automotive · real estate" },
        ],
      },
      work: {
        title: "Selected work",
        intro: "Results from real ad accounts, with currency and period as shown in the ads manager. Client names are withheld for privacy.",
        filterAll: "All",
        open: "View case study",
        labels: { goal: "Goal", challenge: "Challenge", role: "My role", execution: "Execution", results: "Results", period: "Period", currency: "Currency", platform: "Platform", evidence: "Ads manager screenshot" },
        close: "Close",
      },
      services: {
        title: "Services",
        intro: "What I do, and what you get from it.",
      },
      process: {
        title: "How I work",
        steps: [
          { t: "Account audit", d: "I review the current account: objectives, campaign structure, tracking, and what has worked before." },
          { t: "Structure & plan", d: "Campaigns split by service and branch, with the monthly budget allocated across platforms." },
          { t: "Launch & test", d: "Several ads per service with different Arabic copy, compared at ad level." },
          { t: "Optimise & reallocate", d: "Pause the weakest, move budget to the best by cost per result, not by gut feeling." },
          { t: "Report", d: "Regular reporting on cost per conversation, lead quality and confirmed bookings." },
        ],
      },
      skills: { title: "Skills & tools" },
      experience: { title: "Experience", education: "Education & certificates", present: "Present", freelance: "Freelance" },
      contact: {
        title: "Have a campaign to scale, or an account that needs an audit?",
        lead: "Send me your business, city and rough monthly budget on WhatsApp or email, and I'll reply with an initial plan.",
        whatsapp: "WhatsApp",
        whatsappHint: "Pick the closest number and the chat opens directly.",
        email: "Email",
        copy: "Copy",
        copied: "Copied",
        instagram: "Instagram",
        linkedin: "LinkedIn",
        waMessage: "Hi Mohamed, I'd like to talk about an ad campaign.",
      },
      footer: "Mohamed Mosad — Media Buyer",
      skipLink: "Skip to content",
    },
  },

  /* ---------------- العملاء والقطاعات ----------------
     clients: الأسماء التي تظهر في الشريط المتحرك. لإضافة لوجو: أضف logo: "assets/img/logos/اسم.svg"
     sectors: كل قطاع وعملاؤه وما تم العمل عليه.
  -------------------------------------------------------- */
  clients: [
    { name: "Tulip Medical Center", sector: "beauty" },
    { name: "Be You Clinic", sector: "beauty" },
    { name: "مملكة الجمال", sector: "beauty" },
    { name: "Alweam Cars", sector: "cars" },
    { name: "Al Fares Cars", sector: "cars" },
    { name: "REDLINE", sector: "realestate" },
  ],
  sectors: [
    {
      id: "beauty",
      ar: { t: "التجميل والعيادات", d: "حملات Meta وسناب شات لخدمات الجلدية، الأسنان، الليزر، العناية بالبشرة، وزراعة الشعر، موجّهة إلى واتساب.", tags: ["جلدية", "أسنان", "ليزر", "زراعة شعر"] },
      en: { t: "Aesthetics & clinics", d: "Meta and Snapchat campaigns for dermatology, dental, laser, skin care and hair transplant services, routed to WhatsApp.", tags: ["Dermatology", "Dental", "Laser", "Hair transplant"] },
    },
    {
      id: "cars",
      ar: { t: "السيارات", d: "إعلانات Meta لموديلات وعروض السيارات، بإعلان ونص عربي مستقل لكل موديل.", tags: ["عروض الموديلات", "حملات زيارات"] },
      en: { t: "Automotive", d: "Meta ads for car models and offers, with a separate ad and Arabic copy for each model.", tags: ["Model offers", "Traffic campaigns"] },
    },
    {
      id: "realestate",
      ar: { t: "العقارات", d: "حملات إعلانية لشركة تسويق عقاري.", tags: [] },
      en: { t: "Real estate", d: "Ad campaigns for a real-estate company.", tags: [] },
    },
  ],

  /* ---------------- المشاريع / دراسات الحالة ----------------
     category: يُستخدم في أزرار التصفية (meta / snapchat / tiktok)
     metrics: الأرقام البارزة على البطاقة (من لوحة الإعلانات فقط)
  -------------------------------------------------------------- */
  categories: [], // أزرار التصفية تظهر فقط إذا أضفت فئات هنا، مثال: { id: "cars", ar: "سيارات", en: "Automotive" }

  projects: [
    {
      id: "auto-dealer-meta",
      categories: ["meta", "cars"],
      images: ["assets/img/case-auto-meta.webp"],
      spark: { type: "bars", best: "max", unit: "", values: [78, 45, 78, 951, 681, 416], ar: "نقرات الرابط لكل إعلان", en: "Link clicks by ad" },
      ar: {
        title: "زيارات منخفضة التكلفة لإعلانات سيارات BYD",
        sector: "وكيل سيارات",
        platform: "Meta (منشورات إنستجرام)",
        period: "22 أبريل – 21 مايو 2026",
        currency: "دولار أمريكي (USD)",
        goal: "جلب نقرات على الرابط لعروض موديلات BYD، ومنها عرض عيد الأضحى.",
        challenge: "تشغيل 14 إعلانًا لموديلات وعروض مختلفة في نفس الوقت، مع الحفاظ على تكلفة النقرة منخفضة وتكرار ظهور معقول.",
        role: "ميديا باير: إعداد الإعلانات، كتابة النصوص العربية لكل موديل، ومقارنة الأداء على مستوى الإعلان.",
        execution: [
          "إعلان مستقل لكل موديل وعرض (BYD Qin Plus 2025 وغيرها) بنص عربي خاص.",
          "قياس تكلفة النقرة والوصول والتكرار لكل إعلان.",
          "إبقاء التكرار بين 1.12 و1.53 لتجنب إرهاق الجمهور.",
        ],
        results: [
          "تكلفة نقرة الرابط بين 0.09$ و0.21$ عبر الإعلانات الظاهرة.",
          "الإعلان الأعلى حجمًا: 951 نقرة ووصول 44,205 بتكلفة 0.21$.",
          "إعلان ثانٍ: 681 نقرة ووصول 20,465 بتكلفة 0.14$.",
        ],
      },
      en: {
        title: "Low-cost traffic for BYD car ads",
        sector: "Car dealership",
        platform: "Meta (Instagram posts)",
        period: "22 Apr – 21 May 2026",
        currency: "US dollar (USD)",
        goal: "Drive link clicks to BYD model offers, including an Eid Al-Adha promotion.",
        challenge: "Running 14 ads for different models and offers at once while keeping cost per click low and frequency reasonable.",
        role: "Media buyer: ad setup, Arabic copy per model, and ad-level performance comparison.",
        execution: [
          "A separate ad for each model and offer (BYD Qin Plus 2025 and others) with its own Arabic copy.",
          "Tracked cost per click, reach and frequency per ad.",
          "Kept frequency between 1.12 and 1.53 to avoid audience fatigue.",
        ],
        results: [
          "Cost per link click between $0.09 and $0.21 across the visible ads.",
          "Highest-volume ad: 951 clicks, 44,205 reach at $0.21.",
          "Second ad: 681 clicks, 20,465 reach at $0.14.",
        ],
      },
      metrics: [
        { value: "$0.09", ar: "أقل تكلفة نقرة", en: "Lowest CPC" },
        { value: "951", ar: "نقرة لأفضل إعلان", en: "Clicks, top ad" },
        { value: "44.2K", ar: "وصول لأفضل إعلان", en: "Reach, top ad" },
      ],
    },

    {
      id: "meta-account-scale",
      categories: ["meta"],
      images: ["assets/img/case-meta-account.webp"],
      spark: { type: "bars", best: "max", unit: "", values: [134, 762, 291, 418, 647, 56, 151, 437, 40, 810], ar: "نقرات الرابط لكل حملة (آخر 10 حملات ظاهرة)", en: "Link clicks by campaign (last 10 visible)" },
      ar: {
        title: "حساب Meta بإنفاق ربع مليون درهم",
        sector: "حساب إعلاني متعدد الحملات",
        platform: "Meta Ads",
        period: "حملات حتى مارس 2024",
        currency: "درهم إماراتي (AED)",
        goal: "توليد زيارات على نطاق واسع عبر عدة حملات متوازية.",
        challenge: "مع هذا الحجم، تختلف الحملات كثيرًا: بعضها بتكلفة نقرة 2.28 درهم، وبعضها تجاوز 29 درهمًا.",
        role: "إدارة الحملات ومتابعة مؤشرات CPM وCPC وCTR على مستوى كل حملة.",
        execution: [
          "مقارنة الحملات جنبًا إلى جنب على CPM وCPC وCTR.",
          "تحديد الحملات ذات التكلفة المرتفعة (CTR أقل من 0.2%) لإيقافها أو إعادة بنائها.",
        ],
        results: [
          "245,127.25 درهم إنفاق إجمالي.",
          "10,397,206 ظهور و67,541 نقرة على الرابط.",
          "متوسط 3.63 درهم للنقرة و23.58 درهم لكل ألف ظهور.",
          "أفضل حملة ظاهرة: 810 نقرة بتكلفة 2.28 درهم ونسبة نقر 1.25%.",
        ],
      },
      en: {
        title: "A Meta account with a quarter-million dirham spend",
        sector: "Multi-campaign ad account",
        platform: "Meta Ads",
        period: "Campaigns up to March 2024",
        currency: "UAE dirham (AED)",
        goal: "Drive traffic at scale across several parallel campaigns.",
        challenge: "At this volume campaigns vary widely: some at AED 2.28 per click, others above AED 29.",
        role: "Managing campaigns and tracking CPM, CPC and CTR per campaign.",
        execution: [
          "Compared campaigns side by side on CPM, CPC and CTR.",
          "Flagged high-cost campaigns (CTR under 0.2%) to pause or rebuild.",
        ],
        results: [
          "AED 245,127.25 total spend.",
          "10,397,206 impressions and 67,541 link clicks.",
          "AED 3.63 average CPC and AED 23.58 CPM.",
          "Best visible campaign: 810 clicks at AED 2.28 with a 1.25% CTR.",
        ],
      },
      metrics: [
        { value: "245K", unitAr: "د.إ", unitEn: "AED", ar: "إنفاق إجمالي", en: "Total spend" },
        { value: "10.4M", ar: "ظهور", en: "Impressions" },
        { value: "67.5K", ar: "نقرة على الرابط", en: "Link clicks" },
      ],
    },
  ],

  /* ---------------- الخدمات ---------------- */
  services: [
    {
      icon: "meta",
      ar: { t: "إعلانات Meta", d: "حملات فيسبوك وإنستجرام لجلب عملاء ورسائل واتساب، مقسّمة حسب الخدمة والفرع.", gain: "تعرف تكلفة كل استفسار لكل خدمة." },
      en: { t: "Meta Ads", d: "Facebook and Instagram campaigns for leads and WhatsApp messages, split by service and branch.", gain: "You know the cost of every inquiry, per service." },
    },
    {
      icon: "snap",
      ar: { t: "إعلانات سناب شات", d: "حملات Leads ومحتوى بوجوه الأطباء أو صاحب النشاط، مناسبة لجمهور الخليج.", gain: "وصول لجمهور لا تصله على إنستجرام." },
      en: { t: "Snapchat Ads", d: "Lead and content campaigns featuring doctors or the business owner, built for Gulf audiences.", gain: "Reach people you won't reach on Instagram." },
    },
    {
      icon: "tiktok",
      ar: { t: "إعلانات تيك توك", d: "إعداد الحساب، سكربتات فيديو قصيرة بالعربية، واختبار الإعلانات.", gain: "إعلانات تشبه محتوى المنصة فتُشاهد للنهاية." },
      en: { t: "TikTok Ads", d: "Account setup, short Arabic video scripts and ad testing.", gain: "Ads that look native to the platform, so people watch them." },
    },
    {
      icon: "wa",
      ar: { t: "قمع حجز عبر واتساب", d: "حملات Click-to-WhatsApp وربط WATI / WhatsApp Cloud API مع Meta لقياس الحجوزات المؤكدة.", gain: "تقيس الحجز، لا مجرد الرسالة." },
      en: { t: "WhatsApp booking funnel", d: "Click-to-WhatsApp campaigns and WATI / WhatsApp Cloud API connected to Meta to track confirmed bookings.", gain: "You measure bookings, not just messages." },
    },
    {
      icon: "audit",
      ar: { t: "مراجعة الحسابات الإعلانية", d: "فحص الأهداف والهيكل والتتبع (Meta CAPI) وإصلاح الأخطاء مثل تحسين النقرات بدل المحادثات.", gain: "توقف الإنفاق الضائع قبل زيادة الميزانية." },
      en: { t: "Ad account audits", d: "Checking objectives, structure and tracking (Meta CAPI), and fixing mistakes like optimising for clicks instead of conversations.", gain: "Stop wasted spend before adding budget." },
    },
    {
      icon: "pen",
      ar: { t: "نصوص إعلانية وسكربتات بالعربية", d: "كتابة نصوص الإعلانات وسكربتات الريلز والفيديو لكل خدمة، باللهجة المناسبة للسوق.", gain: "رسالة واضحة بلغة عميلك." },
      en: { t: "Arabic ad copy & scripts", d: "Ad copy and Reels / video scripts for each service, in the right dialect for the market.", gain: "A clear message in your customer's language." },
    },
  ],

  /* ---------------- المهارات والأدوات (بدون نسب مئوية) ---------------- */
  skills: [
    { ar: "المنصات الإعلانية", en: "Ad platforms", items: ["Meta Ads Manager", "Meta Business Manager", "Snapchat Ads Manager", "TikTok Ads"] },
    { ar: "التتبع والأتمتة", en: "Tracking & automation", items: ["Meta CAPI", "WhatsApp Business / Cloud API", "WATI", "Google Sheets"] },
    { ar: "البحث والإبداع", en: "Research & creative", itemsAr: ["مكتبة إعلانات Meta", "اختبار الإعلانات", "نصوص وسكربتات عربية", "Canva"], itemsEn: ["Meta Ad Library", "Creative testing", "Arabic copy & scripts", "Canva"] },
    { ar: "الاستراتيجية", en: "Strategy", itemsAr: ["توزيع الميزانية", "توسيع الحملات (Scaling)", "بناء القمع التسويقي", "اختيار هدف الحملة"], itemsEn: ["Budget allocation", "Campaign scaling", "Funnel strategy", "Objective selection"] },
    { ar: "الاستهداف", en: "Targeting", itemsAr: ["بحث الجمهور", "جماهير مخصصة", "جماهير مشابهة (Lookalike)", "إعادة الاستهداف"], itemsEn: ["Audience research", "Custom audiences", "Lookalike audiences", "Retargeting"] },
    { ar: "توليد العملاء والتحويل", en: "Leads & conversion", itemsAr: ["Lead Forms", "Click-to-WhatsApp", "تحسين التحويل", "جودة العملاء المحتملين"], itemsEn: ["Lead Forms", "Click-to-WhatsApp", "Conversion optimisation", "Lead quality"] },
    { ar: "التحليل والتقارير", en: "Analysis & reporting", itemsAr: ["CPL · CPC · CPM · CTR", "تكلفة المحادثة", "اختبار A/B", "تقارير الإدارة بالعربية"], itemsEn: ["CPL · CPC · CPM · CTR", "Cost per conversation", "A/B testing", "Arabic management reports"] },
  ],

  /* ---------------- الخبرات ---------------- */
  // الخبرات تظهر في خانة واحدة تتبدّل تلقائيًا. هذا أقصى عدد نقاط يظهر لكل خبرة (الأولى في القائمة هي التي تظهر).
  experienceMaxPoints: 4,

  experience: [
    {
      freelance: true, tab: "Tulip Medical",
      ar: { role: "ميديا باير · Meta وسناب شات", org: "Tulip Medical Center", place: "الشارقة ورأس الخيمة، الإمارات",
        points: [
          "إدارة الإعلانات لمركز طبي بفرعين: تجميل، أسنان، ليزر، وعناية بالبشرة.",
          "بناء خطة إعلامية بقيمة 40,000 درهم شهريًا على إنستجرام وسناب شات، مقسّمة حسب الفرع والخدمة.",
          "حملات سناب شات بظهور أطباء العيادة (جلدية وأسنان) لفرع رأس الخيمة.",
          "ربط WATI مع Meta لقياس الحجوزات المؤكدة من إعلانات واتساب، وتقارير شهرية بالعربية للإدارة.",
        ] },
      en: { role: "Media Buyer · Meta & Snapchat", org: "Tulip Medical Center", place: "Sharjah & Ras Al Khaimah, UAE",
        points: [
          "Run paid acquisition for a two-branch medical centre: aesthetics, dentistry, laser and skin care.",
          "Built an AED 40,000/month media plan across Instagram and Snapchat, split by branch and service.",
          "Snapchat campaigns featuring the clinic's doctors (dermatology and dental) for the Ras Al Khaimah branch.",
          "Connected WATI to Meta to track confirmed bookings from WhatsApp ads; monthly Arabic reports to management.",
        ] },
    },
    {
      freelance: true, tab: "Be You Clinic",
      ar: { role: "ميديا باير · Meta وتوليد عملاء واتساب", org: "Be You Clinic (مملكة الجمال)", place: "دبي وأبوظبي، الإمارات",
        points: [
          "إدارة إعلانات Meta عبر عدة Business Managers وحسابات ووجهات واتساب لمجموعة عيادات متعددة الفروع.",
          "هيكلة الحملات حسب الخدمة: جلدية، ابتسامة هوليوود، زراعة شعر، وجراحة.",
          "إصلاح أخطاء الأهداف (تحسين النقرات مع توجيه لواتساب)، دمج الحملات المتفرقة، وإعادة تفعيل الحملات القوية سابقًا.",
          "نقل الميزانية بين المجموعات الإعلانية حسب تكلفة النتيجة، ودراسة المنافسين عبر مكتبة إعلانات Meta.",
        ] },
      en: { role: "Media Buyer · Meta & WhatsApp lead gen", org: "Be You Clinic (Mamlakat Al Jamal)", place: "Dubai & Abu Dhabi, UAE",
        points: [
          "Managed Meta Ads across multiple Business Managers, ad accounts and WhatsApp destinations for a multi-branch clinic group.",
          "Structured campaigns by service: dermatology, Hollywood Smile, hair transplant and surgery.",
          "Fixed objective mismatches (Link Clicks routed to WhatsApp), consolidated fragmented campaigns and re-activated strong ones.",
          "Reallocated budget between ad sets by cost per result; researched competitors in the Meta Ad Library.",
        ] },
    },
    {
      freelance: false, tab: "Hive Studio",
      ar: { role: "ميديا باير · Meta وسناب شات وتيك توك", org: "Hive Studio Creative Agency", place: "القاهرة، مصر", from: "2024", to: "2026",
        points: [
          "مراجعات حسابات ومقترحات نمو لحسابات سناب شات وتيك توك وMeta لعملاء الوكالة.",
          "قيادة إطلاق حملات Meta وسناب شات، بما فيها قرار البدء بحساب جديد أو البناء على الحساب القائم.",
          "إدارة حملات لعملاء في مصر والخليج من قطاعات مختلفة: تجميل، سيارات، وعقارات.",
          "بناء حملات توليد عملاء (Lead Forms وClick-to-WhatsApp) وحملات زيارات، واختيار الهدف المناسب لكل مرحلة في القمع.",
          "بحث الجمهور وبناء جماهير مخصصة ومشابهة (Lookalike) وحملات إعادة استهداف لزوار الصفحات والمتفاعلين.",
          "اختبار الإعلانات بشكل منظم: عدة نصوص وتصميمات لكل حملة، ومقارنتها على CTR وCPC وتكلفة النتيجة.",
          "كتابة النصوص الإعلانية وسكربتات الفيديو بالعربية، وتجهيز Brief واضح لفريق التصميم والمونتاج.",
          "دراسة إعلانات المنافسين عبر مكتبة إعلانات Meta لاستخراج زوايا وعروض جديدة.",
          "توسيع الحملات الناجحة بزيادة الميزانية تدريجيًا ونقلها من الإعلانات الأضعف، مع متابعة CPM والتكرار.",
          "إعداد تقارير أداء دورية للعملاء توضح الإنفاق والنتائج والخطوة التالية.",
        ] },
      en: { role: "Media Buyer · Meta, Snapchat & TikTok", org: "Hive Studio Creative Agency", place: "Cairo, Egypt", from: "2024", to: "2026",
        points: [
          "Account audits and growth proposals for clients' Snapchat, TikTok and Meta accounts.",
          "Led Meta and Snapchat launches, including the call between a new or existing ad account structure.",
          "Ran campaigns for clients in Egypt and the Gulf across sectors: aesthetics, automotive and real estate.",
          "Built lead-generation (Lead Forms, Click-to-WhatsApp) and traffic campaigns, choosing the right objective for each funnel stage.",
          "Audience research, custom and lookalike audiences, and retargeting of page visitors and engagers.",
          "Structured creative testing: several copy and design variants per campaign, compared on CTR, CPC and cost per result.",
          "Wrote Arabic ad copy and video scripts, and clear briefs for the design and editing team.",
          "Researched competitor ads in the Meta Ad Library to find new angles and offers.",
          "Scaled winning campaigns by raising budgets gradually and shifting spend from weaker ads, while watching CPM and frequency.",
          "Regular performance reports for clients covering spend, results and next steps.",
        ] },
    },
  ],

  education: [
    { ar: { t: "بكالوريوس تكنولوجيا المعلومات", s: "الجامعة المصرية الكورية التكنولوجية · 2024" }, en: { t: "Bachelor's in Information Technology", s: "Egyptian-Korean Technological University · 2024" } },
    { ar: { t: "شهادة التسويق بالأداء – Growth Hacking", s: "دراسة ذاتية · 2026" }, en: { t: "Performance Marketing Certificate – Growth Hacking", s: "Self-study · 2026" } },
  ],
};
